<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
class WelcomeController extends Controller
{

    public function index()
    {
        return view('layout/main');
    }
    public function contact()
    {
        return "contacteaza-ma";
    }
    public function about()
    {
        return view('about');
    }
    public function contactp()
    {
        return view('contactp');
    }
    public function despre(){
        $name="Fiscalitatea astazi";
        return view('despre')->with('name',$name);
    }
    public function despresir(){
        return view('despresir')->with(['name'=>"Pop", 'prenume'=>"Filimon"]);
    }
}
?>
