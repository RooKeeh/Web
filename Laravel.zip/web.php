<?php
use Illuminate\Support\Facades\Route;

Route::get('/', 'App\Http\Controllers\WelcomeController@index');
Route::get('contact', 'App\Http\Controllers\WelcomeController@contact');
Route::get('about', 'App\Http\Controllers\WelcomeController@about');
Route::get('contactp', 'App\Http\Controllers\WelcomeController@contactp');
Route::get('despre', 'App\Http\Controllers\WelcomeController@despre');
Route::get('despresir', 'App\Http\Controllers\WelcomeController@despresir');
?>
