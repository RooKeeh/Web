<?php

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Comanda Trimisa</title>
  <link rel="stylesheet"
        href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="product-grid">
  <h1>Comanda Trimisa!</h1>
  <h3><a href="magazin_logout.php">Continua cumparaturile</a></h3>
</div>
</body>
</html>